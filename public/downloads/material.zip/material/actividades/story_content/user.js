function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5YTgYm5Xm0w":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

