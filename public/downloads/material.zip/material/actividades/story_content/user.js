function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZfctWv8fqx":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

