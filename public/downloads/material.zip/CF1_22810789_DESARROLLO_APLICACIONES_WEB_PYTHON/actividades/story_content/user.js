function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6XfKsKIt63Y":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

